<?php
$mysqli = new mysqli("127.0.0.1", "root", "");

if($mysqli->connect_error){
  echo "Error al conectar.\n";
}else{
  // Create database
  $sql = "CREATE DATABASE IF NOT EXISTS harrygamedb";
  $res = $mysqli->query($sql);
  if($res){
    echo "Database created\n";
  }else{
    echo "Error\n";
  }

  // Connect to database
$mysqli->select_db("harrygamedb");

  //Create table
  $sql = "CREATE TABLE IF NOT EXISTS objects (
    nameObject VARCHAR(30) NOT NULL PRIMARY KEY,
    picture VARCHAR(30) NOT NULL,
    xPosition int NOT NULL,
    yPosition int NOT NULL,
    infomation VARCHAR(1000) NOT NULL,
    canTake BOOLEAN NOT NULL,
    canOpen BOOLEAN NOT NULL,
    canUse BOOLEAN NOT NULL,
    isLocked BOOLEAN NOT NULL,
    isLockedToOpen BOOLEAN NOT NULL,
    isForUnlock BOOLEAN NOT NULL,
    isOpen BOOLEAN NOT NULL,
    objectOpenImg VARCHAR(30) NOT NULL,
    objectClosedImg VARCHAR(30) NOT NULL,
    setImg BOOLEAN NOT NULL,
    imgUsed VARCHAR(30) NOT NULL,
    finished BOOLEAN NOT NULL, 
    displayWidth int NOT NULL,
    displayHeight int NOT NULL
  )";
  $res = $mysqli->query($sql);
  if($res){
    echo "Table created\n";
  }else{
    echo "Error\n";
  }

  // Fill table
  $sql = "INSERT INTO objects VALUES (
    'door'
    'puertaCerrada',
    1190,
    390,
    'Una puerta robusta, ¿a dónde conducirá?',
    0,
    1,
    0,
    1,
    0,
    0,


  )";
}
// nameObject
// picture
// xPosition
// yPosition
// information
// canTake
// canOpen
// canUse
// isLocked
// isLockedToOpen
// isForUnlock
// isOpen
// objectOpenImg
// objectClosedImG
// setImg
// imgUsed
// finished
// displayWidth
// displayHeight

// numberUse **