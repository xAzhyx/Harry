import Phaser from 'phaser';

const menuScene = new Phaser.Scene('Menu');

menuScene.create = function saludo() {
    alert('hi');
};
